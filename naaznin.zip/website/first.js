// script.js
document.getElementById('openPopupBtn').addEventListener('click', function() {
    showPopup();
});

document.getElementById('closePopupBtn').addEventListener('click', function() {
    hidePopup();
});

function showPopup() {
    const popup = document.getElementById('popup');
    popup.classList.add('show');
}

function hidePopup() {
    const popup = document.getElementById('popup');
    popup.classList.remove('show');
}
document.getElementById('detailsForm').addEventListener('submit', async function(event) {
    event.preventDefault();

    const form = event.target;
    const formData = new FormData(form);

    try {
        const response = await fetch('https://getform.io/f/{your-form-endpoint}', {
            method: 'POST',
            body: formData,
        });

        if (response.ok) {
            alert('Form submitted successfully!');
            form.reset();
        } else {
            alert('Error submitting form.');
        }
    } catch (error) {
        alert('Error submitting form.');
        console.error('Error:', error);
    }
});
let slideIndex = 1;
showSlides(slideIndex);

function plusSlides(n) {
  showSlides(slideIndex += n);
}

function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  let i;
  let slides = document.getElementsByClassName("mySlides");
  let dots = document.getElementsByClassName("dot");
  if (n > slides.length) {slideIndex = 1}    
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";  
  }
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
}